package com.cp.sports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsShoppeFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsShoppeFinalApplication.class, args);
	}

}
