package com.cp.sports.exceptions;

public class PaymentServiceException extends RuntimeException {

public PaymentServiceException(String msg)
{
	super(msg);
}
	

}
